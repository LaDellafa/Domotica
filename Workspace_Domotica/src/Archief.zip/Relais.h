/*
 * Bediening.h
 *
 *  Created on: 18 okt. 2015
 *      Author: jensdehoog
 */

#ifndef BEDIENING_H_
#define BEDIENING_H_

void Relais_bediening(int status);

#endif /* BEDIENING_H_ */
