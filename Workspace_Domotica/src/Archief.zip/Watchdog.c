/*
 * Watchdog.c
 *
 *  Created on: 23-okt.-2015
 *      Author: landerdellafaille
 */

int counterOfDeath;

void initWatchdog() {
	counterOfDeath = 30;
}
